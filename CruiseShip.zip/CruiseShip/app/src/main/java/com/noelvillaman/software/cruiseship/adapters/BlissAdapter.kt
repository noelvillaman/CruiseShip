package com.noelvillaman.software.cruiseship.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.noelvillaman.software.cruiseship.R
import com.noelvillaman.software.cruiseship.model.CruiseBliss
import com.noelvillaman.software.cruiseship.viewmodel.BlissViewModel
import java.util.ArrayList

class BlissAdapter internal constructor(
    viewModel: BlissViewModel,
    lifecycleOwner: LifecycleOwner,
) : RecyclerView.Adapter<BlissAdapter.RepoViewHolder>() {

    private var data = CruiseBliss()

    init {
        viewModel.cruiseBlisssList.observe(lifecycleOwner, Observer { bliss ->
            if (bliss != null) {
                data = bliss
            }
        })
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RepoViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.view_list_item, parent, false)
        return RepoViewHolder(view)
    }

    override fun onBindViewHolder(holder: RepoViewHolder, position: Int) {
        holder.bind(data)
    }

    class RepoViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        @BindView(R.id.ship_name)
        lateinit var cruiseNameTextView: TextView
        @BindView(R.id.ship_crew)
        lateinit var cruiseCrewTextView: TextView
        @BindView(R.id.ship_capacity)
        lateinit var cruiseCapicity: TextView
        @BindView(R.id.ship_inagural_date)
        lateinit var cruiseInaguralDate: TextView

        private var bliss: CruiseBliss

        init {
            ButterKnife.bind(this, itemView)
            bliss = CruiseBliss()
            cruiseNameTextView = itemView.findViewById(R.id.ship_name)
            cruiseCrewTextView = itemView.findViewById(R.id.ship_crew)
            cruiseCapicity = itemView.findViewById(R.id.ship_capacity)
            cruiseInaguralDate = itemView.findViewById(R.id.ship_inagural_date)
        }

        fun bind(bliss: CruiseBliss) {
            this.bliss = bliss
            cruiseNameTextView.text = bliss.shipName
            cruiseCrewTextView.text = bliss.crew
            cruiseCapicity.text = bliss.passengerCapacity.toString()
            cruiseInaguralDate.text = bliss.inauguralDate
        }
    }

    override fun getItemCount(): Int {
        return 1
    }
}