package com.noelvillaman.software.cruiseship.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.noelvillaman.software.cruiseship.R
import com.noelvillaman.software.cruiseship.model.CruiseSky
import com.noelvillaman.software.cruiseship.viewmodel.SkyViewModel
import java.util.ArrayList

class SkyAdapter internal constructor(
    viewModel: SkyViewModel,
    lifecycleOwner: LifecycleOwner
) : RecyclerView.Adapter<SkyAdapter.SkyViewHolder>() {

    private var data = CruiseSky()

    init {
        viewModel.cruiseSkyList.observe(lifecycleOwner, Observer { sky ->
            if (sky != null) {
                data = sky
            }
        })
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkyViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.view_list_item, parent, false)
        return SkyViewHolder(view)
    }

    override fun onBindViewHolder(holder: SkyViewHolder, position: Int) {
        holder.bind(data)
    }

    override fun getItemCount() = 1


    class SkyViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        @BindView(R.id.ship_name)
        lateinit var nameTextView: TextView
        @BindView(R.id.ship_crew)
        lateinit var crewTextView: TextView
        @BindView(R.id.ship_capacity)
        lateinit var capacityTextView: TextView
        @BindView(R.id.ship_inagural_date)
        lateinit var inaguralDateTextView: TextView

        private var cruiseSky: CruiseSky

        init {
            ButterKnife.bind(this, itemView)
            cruiseSky = CruiseSky()
            nameTextView = itemView.findViewById(R.id.ship_name)
            crewTextView = itemView.findViewById(R.id.ship_crew)
            capacityTextView = itemView.findViewById(R.id.ship_capacity)
            inaguralDateTextView = itemView.findViewById(R.id.ship_inagural_date)
        }

        fun bind(cruiseSky: CruiseSky) {
            this.cruiseSky = cruiseSky
            nameTextView.text = cruiseSky.shipName
            crewTextView.text = cruiseSky.crew
            capacityTextView.text = cruiseSky.passengerCapacity.toString()
            inaguralDateTextView.text = cruiseSky.inauguralDate
        }
    }
}