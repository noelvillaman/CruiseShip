package com.noelvillaman.software.cruiseship.views

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.Unbinder
import com.noelvillaman.software.cruiseship.R
import com.noelvillaman.software.cruiseship.adapters.SkyAdapter
import com.noelvillaman.software.cruiseship.model.CruiseSky
import com.noelvillaman.software.cruiseship.networking.CruiseApi
import com.noelvillaman.software.cruiseship.viewmodel.SkyViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FragmentInfo : Fragment() {

    @BindView(R.id.recycler_view)
    internal lateinit var listView: RecyclerView
    @BindView(R.id.tv_error)
    internal lateinit var errorTextView: TextView
    @BindView(R.id.loading_view)
    internal lateinit var loadingView: View

    private var unbinder: Unbinder? = null
    private var viewModel: SkyViewModel? = null

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_sky, container, false)
        listView = view.findViewById(R.id.recycler_view)
        loadingView = view.findViewById(R.id.loading_view)
        errorTextView = view.findViewById(R.id.tv_error)
        unbinder = ButterKnife.bind(this, view)
        return inflater.inflate(R.layout.fragment_sky, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        viewModel = ViewModelProvider(this).get(SkyViewModel::class.java)
        listView.addItemDecoration(
            DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL)
        )
        listView.adapter = SkyAdapter(viewModel!!, this)
        listView.layoutManager = LinearLayoutManager(context)
        observeViewModel()
        videosNetworking()

        view.findViewById<Button>(R.id.button_second).setOnClickListener {
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }
    }

    private fun observeViewModel() {
        val nameObserver = Observer<CruiseSky> { repos ->
            if (repos != null) {
                listView.visibility = View.VISIBLE
            }
        }
        viewModel!!.getCruiseSky().observe(viewLifecycleOwner, nameObserver)

        viewModel!!.error.observe(viewLifecycleOwner, Observer<Boolean>{ isError ->
            if (isError) {
                errorTextView.visibility = View.VISIBLE
                listView.visibility = View.GONE
                errorTextView.setText(R.string.app_name)
            } else {
                errorTextView.visibility = View.GONE
                errorTextView.text = null
            }
        })
        viewModel!!.getLoading().observe(viewLifecycleOwner, Observer<Boolean>{ isLoading ->

            loadingView.visibility = if (isLoading) View.VISIBLE else View.GONE
            if (isLoading) {
                errorTextView.visibility = View.GONE
                listView.visibility = View.GONE
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (unbinder != null) {
            unbinder?.unbind()
            unbinder = null
        }
    }

    private fun videosNetworking() {
        val api = CruiseApi.instance
        val call = api?.getSkyInfo()
        call?.enqueue(object : Callback<CruiseSky> {
            override fun onResponse(call: Call<CruiseSky>,
                                    response: Response<CruiseSky>
            ) {
                if (response != null && response.isSuccessful) {
                    Log.i("RESPONSE", response.body().toString())
                    response.body()
                    //generateVodData(limitedObjects)
                }
            }

            override fun onFailure(call: Call<CruiseSky>, t: Throwable) {
                Log.i("RESPONSE", t.message ?: "")
            }
        })
    }
}