package com.noelvillaman.software.cruiseship.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import butterknife.BindView
import butterknife.ButterKnife
import com.noelvillaman.software.cruiseship.R
import com.noelvillaman.software.cruiseship.model.CruiseScape
import com.noelvillaman.software.cruiseship.viewmodel.ScapeViewModel
import java.util.ArrayList

class ScapeAdapter internal constructor(
    viewModel: ScapeViewModel,
    lifecycleOwner: LifecycleOwner
) : RecyclerView.Adapter<ScapeAdapter.RepoViewHolder>() {


    private var data = CruiseScape()

    init {
        viewModel.cruiseScapeList.observe(lifecycleOwner, Observer { scape ->
            if (scape != null) {
                data = scape
            }
        })
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RepoViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.view_list_item, parent, false)
        return RepoViewHolder(view)
    }

    override fun onBindViewHolder(holder: RepoViewHolder, position: Int) {
        holder.bind(data)
    }

    override fun getItemCount() = 1


    class RepoViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        @BindView(R.id.ship_name)
        lateinit var cruiseNameTextView: TextView
        @BindView(R.id.ship_crew)
        lateinit var cruiseCrewTextView: TextView
        @BindView(R.id.ship_capacity)
        lateinit var cruiseCapicity: TextView
        @BindView(R.id.ship_inagural_date)
        lateinit var cruiseInaguralDate: TextView

        private var scape: CruiseScape

        init {
            ButterKnife.bind(this, itemView)
            scape = CruiseScape()
            cruiseNameTextView = itemView.findViewById(R.id.ship_name)
            cruiseCrewTextView = itemView.findViewById(R.id.ship_crew)
            cruiseCapicity = itemView.findViewById(R.id.ship_capacity)
            cruiseInaguralDate = itemView.findViewById(R.id.ship_inagural_date)
        }

        fun bind(scape: CruiseScape) {
            this.scape = CruiseScape()
            cruiseNameTextView.text = scape.shipName
            cruiseCrewTextView.text = scape.passengerCapacity.toString()
            cruiseCapicity.text = scape.crew
            cruiseInaguralDate.text = scape.inauguralDate
        }
    }
}