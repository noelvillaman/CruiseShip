package com.noelvillaman.software.cruiseship.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.noelvillaman.software.cruiseship.model.CruiseSky
import com.noelvillaman.software.cruiseship.networking.CruiseApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SkyViewModel : ViewModel() {
    val cruiseSkyList = MutableLiveData<CruiseSky>()
    val cruiseScapeLoadError = MutableLiveData<Boolean>()
    val loading = MutableLiveData<Boolean>()

    private var cruiseScapeCall: Call<CruiseSky>? = null

    internal val error: LiveData<Boolean>
        get() = cruiseScapeLoadError

    init {
        fetchcruiseScapes()
    }

    internal fun getCruiseSky(): LiveData<CruiseSky> {
        return cruiseSkyList
    }

    internal fun getLoading(): LiveData<Boolean> {
        return loading
    }

    private fun fetchcruiseScapes() {
        loading.value = true
        cruiseScapeCall = CruiseApi.instance?.getSkyInfo()
        cruiseScapeCall!!.enqueue(object : Callback<CruiseSky> {
            override fun onResponse(
                call: Call<CruiseSky>,
                response: Response<CruiseSky>
            ) {
                cruiseScapeLoadError.value = false
                cruiseSkyList.value = response.body()
                loading.value = false
                cruiseScapeCall = null
            }

            override fun onFailure(call: Call<CruiseSky>, t: Throwable) {
                Log.e(javaClass.simpleName, "Error loading cruiseScapes", t)
                cruiseScapeLoadError.value = true
                loading.value = false
                cruiseScapeCall = null
            }
        })
    }

    override fun onCleared() {
        if (cruiseScapeCall != null) {
            cruiseScapeCall!!.cancel()
            cruiseScapeCall = null
        }
    }
}